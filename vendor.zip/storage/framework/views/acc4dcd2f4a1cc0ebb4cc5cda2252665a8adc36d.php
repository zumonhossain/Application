
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card card-outline-info">
                <div class="card-header">
                    <h4 class="user-registration"><i class="mdi mdi-account-circle"></i> All User Recycle</h4>
                    <a href="<?php echo e(url('admin/recycle')); ?>" class="all_link"><i class="mdi mdi-apps"></i> Recycle</a>
                </div>
                <div class="card-body">
                    
                    <?php if(Session::has('restore_success')): ?>
                        <script type="text/javascript">
                            swal({title: "Success!", text: "Income Information Restore Successfully", icon: "success", button: "OK", timer:5000,});
                        </script>
                    <?php endif; ?>
                    <?php if(Session::has('restore_error')): ?>
                        <script type="text/javascript">
                            swal({title: "Opps!",text: "Error! Please try again", icon: "error", button: "OK", timer:5000,});
                        </script>
                    <?php endif; ?>

                    <?php if(Session::has('delete_success')): ?>
                        <script type="text/javascript">
                            swal({title: "Success!", text: "Income Information Delete Successfully", icon: "success", button: "OK", timer:5000,});
                        </script>
                    <?php endif; ?>
                    <?php if(Session::has('delete_error')): ?>
                        <script type="text/javascript">
                            swal({title: "Opps!",text: "Error! Please try again", icon: "error", button: "OK", timer:5000,});
                        </script>
                    <?php endif; ?>

                    <table class="table table-bordered table-striped table-hover custom_table">
                        <thead>
                            <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Date</th>
                            <th>Photo</th>
                            <th>Manage</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $i=1;
                            ?>
                            <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($data->name); ?></td>
                            <td><?php echo e($data->email); ?></td>
                            <td><?php echo e($data->phone); ?></td>
                            <td><?php echo e($data->created_at->format('d M Y')); ?></td>
                            <td>
                                <?php if($data->pic!=''): ?>
                                    <img height="50" src="<?php echo e(asset('uploads/user/'.$data->pic)); ?>" alt="user"/>
                                <?php else: ?>
                                    <img height="50" src="<?php echo e(asset('uploads/user/avatar.png')); ?>" alt="user"/>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a class="btn-info delete-icon" id="restore" data-toggle="modal" data-target="#myRestore" data-id="<?php echo e($data->id); ?>" href="#"><i class="mdi mdi-backup-restore"></i></a>
                                <a class="btn-danger delete-icon" id="delete" data-toggle="modal" data-target="#myDelete" data-id="<?php echo e($data->id); ?>" href="#"><i class="mdi mdi-delete"></i></a>
                            </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <a href="#" class="btn btn-sm btn-info">Print</a>
                    <a href="#" class="btn btn-sm btn-warning">Excel</a>
                    <a href="#" class="btn btn-sm btn-primary">Print</a>
                </div>
                </div>
            </div>
        </div>
    </div>


    <!--restore modal code start -->
    <div id="myRestore" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myRestoreLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form method="post" action="<?php echo e(url('admin/user/restore')); ?>">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header modal_header_title">
                    <h5><i class="fa fa-gg-circle"></i> Confirm Message</h5>
                </div>
                <div class="modal-body modal_card">
                    <input type="hidden" name="modal_id" id="modal_id" />
                    Are you want to sure Restore this data?
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-info waves-effect">Confirm</button>
                    <button type="button" class="btn btn-info waves-effect" data-dismiss="modal">Close</button>
                </div>
            </div>
            </form>
        </div>
    </div>

    <!--delete modal code start -->
    <div id="myDelete" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myDeleteLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form method="post" action="<?php echo e(url('admin/user/delete')); ?>">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header modal_header_title">
                    <h5><i class="fa fa-gg-circle"></i> Confirm Message</h5>
                </div>
                <div class="modal-body modal_card">
                    <input type="hidden" name="modal_id" id="modal_id" />
                    Are you want to sure delete this data?
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-info waves-effect">Confirm</button>
                    <button type="button" class="btn btn-info waves-effect" data-dismiss="modal">Close</button>
                </div>
            </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Server\htdocs\Application\resources\views/admin/recycle/user.blade.php ENDPATH**/ ?>