
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card card-outline-info">
                <div class="card-header">
                    <h4 class="user-registration"><i class="mdi mdi-account-circle"></i> Update Expense Category</h4>
                    <a href="<?php echo e(url('admin/expense/category')); ?>" class="all_link"><i class="mdi mdi-grid"></i> All Category</a>
                </div>
                <div class="card-body">
                    <?php if(Session::has('success')): ?>
                        <script type="text/javascript">
                            swal({title: "Success!", text: "Expense Category Update Successfully", icon: "success", button: "OK", timer:5000,});
                        </script>
                    <?php endif; ?>
                    <?php if(Session::has('error')): ?>
                        <script type="text/javascript">
                            swal({title: "Opps!",text: "Error! Please try again", icon: "error", button: "OK", timer:5000,});
                        </script>
                    <?php endif; ?>
                    <form method="post" action="<?php echo e(url('admin/expense/category/update')); ?>" class="form-horizontal">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label class="col-md-3 text-right control-label col-form-label">Category Name<span class="require_star">*</span></label>
                            <div class="col-md-7">
                                <input type="text" name="name" class="form-control" value="<?php echo e($data->expcate_name); ?>">
                                <input type="hidden" name="id" class="form-control" value="<?php echo e($data->expcate_id); ?>">
                                <input type="hidden" name="slug" class="form-control" value="<?php echo e($data->expcate_slug); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 text-right control-label col-form-label">Remarks</label>
                            <div class="col-md-7">
                                <input type="text" name="remarks" class="form-control" value="<?php echo e($data->expcate_remarks); ?>">
                            </div>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-info registration-btn">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Server\htdocs\Application\resources\views/admin/expense-category/edit.blade.php ENDPATH**/ ?>