<!DOCTYPE html>
<html>
    <head>
      <title>PDF</title>
      <style>
          .wrapper{
            width: 600px;
            margin: 0px auto;
          }

          h1{
              text-align: center;
          }


      </style>
    </head>
    <body>
        <div class="wrapper">
            <h1>MONTHLY SUMMARY</h1>
            <table id="inexsummary" class="table table-bordered table-striped table-hover custom_table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Category</th>
                        <th>Details</th>
                        <th>Credit</th>
                        <th>Debit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->income_date); ?></td>
                        <td><?php echo e($data->category->incate_name); ?></td>
                        <td><?php echo e($data->income_details); ?></td>
                        <td><?php echo e($data->income_amount); ?></td>
                        <td>---</td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $expense; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->expense_date); ?></td>
                        <td><?php echo e($data->category->expcate_name); ?></td>
                        <td><?php echo e($data->expense_details); ?></td>
                        <td>---</td>
                        <td><?php echo e($data->expense_amount); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th></th>
                        <th></th>
                        <th style="text-align: right; color:gray;">Total = </th>
                        <th style="color: #1976d2;"><?php echo e($incomeTotal); ?></th>
                        <th style="color:#1976d2;"><?php echo e($expenseTotal); ?></th>
                    </tr>
                    <tr>
                        <th class="text-center" colspan="5">
                            <span style="color:gray; ">Total Saving = </span>
                            <?php if($incomeTotal > $expenseTotal): ?>
                                <span style="color: #1976d2;"><?php echo e($incomeTotal-$expenseTotal); ?></span>
                            <?php else: ?>
                                <span style="color: #1976d2;"><?php echo e($incomeTotal-$expenseTotal); ?></span>
                            <?php endif; ?>
                        </th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </body>
</html>
<?php /**PATH F:\Server\htdocs\Application\resources\views/admin/summary/pdf.blade.php ENDPATH**/ ?>