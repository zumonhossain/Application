
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-4">
            <div class="card card-inverse card-info">
                <div class="card-body">
                    <div class="d-flex">
                        <div class="m-r-20 align-self-center">
                            <h1 class="text-white"><i class="ti-light-bulb"></i></h1></div>
                        <div class="link-share">
                            <h3 class="card-title">All User</h3>
                            <a href="<?php echo e(url('admin/user')); ?>"><i class="fa fa-share-square fa-lg"></i> Manage User</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 text-right">
                            <h2 class="font-light text-white"><sup><small></small></sup>
                                    <?php if($user<10): ?>
                                      0<?php echo e($user); ?>

                                    <?php else: ?>
                                      <?php echo e($user); ?>

                                    <?php endif; ?>
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-inverse card-info">
                <div class="card-body">
                    <div class="d-flex">
                        <div class="m-r-20 align-self-center">
                            <h1 class="text-white"><i class="ti-light-bulb"></i></h1></div>
                        <div class="link-share">
                            <h3 class="card-title">Income Category</h3>
                            <a href="<?php echo e(url('admin/income/category')); ?>"><i class="fa fa-share-square fa-lg"></i> Manage Income Category</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 text-right">
                            <h2 class="font-light text-white"><sup><small></small></sup>
                                    <?php if($incomeCategory<10): ?>
                                      0<?php echo e($incomeCategory); ?>

                                    <?php else: ?>
                                      <?php echo e($incomeCategory); ?>

                                    <?php endif; ?>
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-inverse card-info">
                <div class="card-body">
                    <div class="d-flex">
                        <div class="m-r-20 align-self-center">
                            <h1 class="text-white"><i class="ti-light-bulb"></i></h1></div>
                        <div class="link-share">
                            <h3 class="card-title">Income</h3>
                            <a href="<?php echo e(url('admin/income')); ?>"><i class="fa fa-share-square fa-lg"></i> Manage Income</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 text-right">
                            <h2 class="font-light text-white"><sup><small></small></sup>
                                    <?php if($income<10): ?>
                                      0<?php echo e($income); ?>

                                    <?php else: ?>
                                      <?php echo e($income); ?>

                                    <?php endif; ?>
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-inverse card-info">
                <div class="card-body">
                    <div class="d-flex">
                        <div class="m-r-20 align-self-center">
                            <h1 class="text-white"><i class="ti-light-bulb"></i></h1></div>
                        <div class="link-share">
                            <h3 class="card-title">Expense Category</h3>
                            <a href="<?php echo e(url('admin/expense/category')); ?>"><i class="fa fa-share-square fa-lg"></i> Manage Expense Category</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 text-right">
                            <h2 class="font-light text-white"><sup><small></small></sup>
                                    <?php if($expenseCategory<10): ?>
                                      0<?php echo e($expenseCategory); ?>

                                    <?php else: ?>
                                      <?php echo e($expenseCategory); ?>

                                    <?php endif; ?>
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-inverse card-info">
                <div class="card-body">
                    <div class="d-flex">
                        <div class="m-r-20 align-self-center">
                            <h1 class="text-white"><i class="ti-light-bulb"></i></h1></div>
                        <div class="link-share">
                            <h3 class="card-title">Expense</h3>
                            <a href="<?php echo e(url('admin/expense')); ?>"><i class="fa fa-share-square fa-lg"></i> Manage Expense</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 text-right">
                            <h2 class="font-light text-white"><sup><small></small></sup>
                                    <?php if($expense<10): ?>
                                      0<?php echo e($expense); ?>

                                    <?php else: ?>
                                      <?php echo e($expense); ?>

                                    <?php endif; ?>
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Server\htdocs\Application\resources\views/admin/manage/manage.blade.php ENDPATH**/ ?>