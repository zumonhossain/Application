
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card card-outline-info">
                <div class="card-header">
                    <h4 class="user-registration"><i class="mdi mdi-account-circle"></i> All Income Recycle</h4>
                    <a href="<?php echo e(url('admin/income')); ?>" class="all_link"><i class="mdi mdi-apps"></i> All Income</a>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped table-hover custom_table">
                    <thead>
                        <tr>
                        <th>No</th>
                        <th>Income Details</th>
                        <th>Income Category Name</th>
                        <th>Income Amount</th>
                        <th>Income Date</th>
                        <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $i=1;
                        ?>
                        <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($data->income_details); ?></td>
                        <td><?php echo e($data->category->incate_name); ?></td>
                        <td><?php echo e($data->income_amount); ?></td>
                        <td><?php echo e($data->income_date); ?></td>
                        <td>
                            <a class="btn-info edit-icon" href="<?php echo e(url('admin/income/restore/'.$data->income_slug)); ?>"><i class="mdi mdi-backup-restore"></i></a>
                            <a class="btn-danger delete-icon" id="softDelete" data-toggle="modal" data-target="#softDelModal" data-id="<?php echo e($data->income_id); ?>" href="#"><i class="mdi mdi-delete"></i></a>
                        </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <a href="#" class="btn btn-sm btn-info">Print</a>
                    <a href="#" class="btn btn-sm btn-warning">Excel</a>
                    <a href="#" class="btn btn-sm btn-primary">Print</a>
                </div>
                </div>
            </div>
        </div>
    </div>


    <!--delete modal code start -->
    <div id="softDelModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <form method="post" action="<?php echo e(url('admin/income/rycle/delete')); ?>">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header modal_header_title">
                    <h5><i class="fa fa-gg-circle"></i> Confirm Message</h5>
                </div>
                <div class="modal-body modal_card">
                    <input type="hidden" name="modal_id" id="modal_id" />
                    Are you want to sure delete this data?
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-info waves-effect">Confirm</button>
                    <button type="button" class="btn btn-info waves-effect" data-dismiss="modal">Close</button>
                </div>
            </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Server\htdocs\Application\resources\views/admin/income/rycle.blade.php ENDPATH**/ ?>