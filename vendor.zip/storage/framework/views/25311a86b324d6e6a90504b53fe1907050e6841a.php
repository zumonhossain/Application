
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card card-outline-info">
                <div class="card-header">
                    <h4 class="user-registration"><i class="mdi mdi-account-circle"></i> User Registration</h4>
                    <a href="<?php echo e(url('admin/user')); ?>" class="all_link"><i class="mdi mdi-grid"></i> All User</a>
                </div>
                <div class="card-body">
                    <?php if(Session::has('success')): ?>
                    <script type="text/javascript">
                        swal({title: "Success!", text: "User Information save Successfully!", icon: "success", button: "OK", timer:5000,});
                    </script>
                    <?php endif; ?>
                    <?php if(Session::has('error')): ?>
                    <script type="text/javascript">
                        swal({title: "Opps!",text: "Error! Please try again", icon: "error", button: "OK", timer:5000,});
                    </script>
                    <?php endif; ?>
                    <form method="post" action="<?php echo e(url('admin/user/submit')); ?>" class="form-horizontal" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label class="col-md-3 text-right control-label col-form-label">Name<span class="require_star">*</span></label>
                            <div class="col-md-7">
                                <input type="text" name="name" class="form-control" placeholder="Your Name" value="<?php echo e(old('name')); ?>">
                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label class="col-md-3 text-right control-label col-form-label">Email<span class="require_star">*</span></label>
                            <div class="col-md-7">
                                <input type="email" name="email" class="form-control" placeholder="Email" value="<?php echo e(old('email')); ?>">
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 text-right control-label col-form-label">Phone Number</label>
                            <div class="col-md-7">
                                <input type="number" name="phone" class="form-control" placeholder="Phone" value="<?php echo e(old('phone')); ?>">
                            </div>
                        </div>
                        <div class="form-group row <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label class="col-md-3 text-right control-label col-form-label">Password<span class="require_star">*</span></label>
                            <div class="col-md-7">
                                <input type="password" name="password" class="form-control" placeholder="Password">
                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row <?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                            <label class="col-md-3 text-right control-label col-form-label">Confirm Password<span class="require_star">*</span></label>
                            <div class="col-md-7">
                                <input type="password" name="password_confirmation" class="form-control" placeholder="Confirm Password">
                                <?php if($errors->has('password_confirmation')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label text-right col-md-3">Image Upload</label>
                            <div class="col-md-7">
                                <input type="file" class="form-control" name="pic"value="<?php echo e(old('pic')); ?>">
                            </div>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-info registration-btn">REGISTRATION</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Server\htdocs\Application\resources\views/admin/user/add.blade.php ENDPATH**/ ?>