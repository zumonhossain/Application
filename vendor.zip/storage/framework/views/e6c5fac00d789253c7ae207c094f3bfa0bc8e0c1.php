
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card card-outline-info">
                <div class="card-header">
                    <h4 class="user-registration"><i class="mdi mdi-account-circle"></i> Update User Registration</h4>
                    <a href="<?php echo e(url('admin/user')); ?>" class="all_link"><i class="mdi mdi-grid"></i> All User</a>
                </div>
                <div class="card-body">
                    <?php if(Session::has('success')): ?>
                    <script type="text/javascript">
                        swal({title: "Success!", text: "User Information Update Successfully!", icon: "success", button: "OK", timer:5000,});
                    </script>
                    <?php endif; ?>
                    <?php if(Session::has('error')): ?>
                    <script type="text/javascript">
                        swal({title: "Opps!",text: "Error! Please try again", icon: "error", button: "OK", timer:5000,});
                    </script>
                    <?php endif; ?>
                    <form method="post" action="<?php echo e(url('admin/user/update')); ?>" class="form-horizontal" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label class="col-md-3 text-right control-label col-form-label">Name<span class="require_star">*</span></label>
                            <div class="col-md-7">
                                <input type="text" name="name" class="form-control" value="<?php echo e($data->name); ?>">
                                <input type="hidden" name="id" class="form-control" value="<?php echo e($data->id); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 text-right control-label col-form-label">Email<span class="require_star">*</span></label>
                            <div class="col-md-7">
                                <input type="email" name="email" class="form-control" value="<?php echo e($data->email); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 text-right control-label col-form-label">Phone Number</label>
                            <div class="col-md-7">
                                <input type="number" name="phone" class="form-control" value="<?php echo e($data->phone); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 text-right control-label col-form-label">Password<span class="require_star">*</span></label>
                            <div class="col-md-7">
                                <input type="password" name="password" class="form-control" value="<?php echo e($data->password); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 text-right control-label col-form-label">Confirm Password<span class="require_star">*</span></label>
                            <div class="col-md-7">
                                <input type="password" name="password_confirmation" class="form-control" value="<?php echo e($data->password); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label text-right col-md-3">Image Upload</label>
                            <div class="col-md-4">
                                <input type="file" class="form-control" name="pic" value="<?php echo e(old('pic')); ?>">
                            </div>
                            <div class="col-sm-3">
                                <?php if($data->pic!=''): ?>
                                    <img height="100" width="100" src="<?php echo e(asset('uploads/user/'.$data->pic)); ?>" class="img-thumbail"/>
                                <?php else: ?>
                                    <img height="100" width="100" src="<?php echo e(asset('uploads/user/avatar.jpg')); ?>"/>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-info registration-btn">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Server\htdocs\Application\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>